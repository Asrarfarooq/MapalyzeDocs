import os

# pip install Pillow
from PIL import Image

# pip install fpdf
from fpdf import FPDF

# pip install svglib
from svglib.svglib import svg2rlg

from reportlab.graphics import renderPDF

def convert_image(png_file, output_format, output_file):
    # Open the PNG image
    image = Image.open(png_file)

    # Convert to JPEG
    if output_format == 'jpeg':
        image.save(output_file, 'JPEG')


    # Convert to PDF
    elif output_format == 'pdf':
        pdf = FPDF('P', 'mm', 'A4')  # Set the PDF page size to A4 (210mm x 297mm)

        # Calculate the image size to fit the A4 page while preserving aspect ratio
        img_width, img_height = image.size
        pdf_width = 210  # A4 width in mm
        pdf_height = 297  # A4 height in mm

        img_ratio = img_width / img_height
        pdf_ratio = pdf_width / pdf_height

        if img_ratio > pdf_ratio:
            # Image is wider, adjust width and height
            pdf_image_width = pdf_width
            pdf_image_height = pdf_width / img_ratio
        else:
            # Image is taller or has the same aspect ratio, adjust width and height
            pdf_image_width = pdf_height * img_ratio
            pdf_image_height = pdf_height

        # Calculate the position to center the image horizontally and vertically on the A4 page
        pdf_image_x = (pdf_width - pdf_image_width) / 2
        pdf_image_y = (pdf_height - pdf_image_height) / 2

        pdf.add_page()
        pdf.image(png_file, pdf_image_x, pdf_image_y, pdf_image_width, pdf_image_height)
        pdf.output(output_file)
        
    # Convert to SVG (Vector format)
    elif output_format == 'svg':
        drawing = svg2rlg(png_file)
        renderPDF.drawToFile(drawing, output_file)

    else:
        print("Unsupported output format.")

# Specify the input PNG file
current_directory = os.getcwd()

png_file = os.path.join(current_directory, 'test_floorplan.png')
jpg_output = os.path.join(current_directory, 'result', 'JPG.jpg')
pdf_output = os.path.join(current_directory, 'result', 'PDF.pdf')
svg_output = os.path.join(current_directory, 'result', 'SVG.jpg')

# Convert to JPEG
convert_image(png_file, 'jpeg', jpg_output)

# Convert to PDF
convert_image(png_file, 'pdf', pdf_output)

# Convert to SVG
convert_image(png_file, 'svg', svg_output)