import os

jpg = os.getcwd() + "\\result\\JPG.jpg"
svg = os.getcwd() + "\\result\\SVG.svg"
pdf = os.getcwd() + "\\result\\PDF.pdf"

def create(input):
    f = open(input, "w")
    f.close()

create(jpg)
create(svg)
create(pdf)